<?php

require_once("url.php");
require_once("conexao.php");
require_once("../models/user.php");
require_once("../models/Message.php");
require_once("../dao/UserDAO.php");

$message = new Message($BASE_URL);
$userDao = new UserDAO($conn, $BASE_URL);

$type = filter_input(INPUT_POST, "type");

if($type ==="register"){

    $nome = filter_input(INPUT_POST, "name");
    $ultimoNome = filter_input(INPUT_POST, "lastname");
    $email = filter_input(INPUT_POST, "email");
    $password = filter_input(INPUT_POST, "password");
    $confirmpassword = filter_input(INPUT_POST, "confirmpassword");

    echo"$nome $ultimoNome $email $password $confirmpassword";


    if($nome && $ultimoNome && $email && $password) {
        
        if($password != $confirmpassword){
            $message->setMessage("As senhas não são iguais", "error", "back");
            
        }
//Verifica se o email já está cadastrado no sistema

        else if($userDao ->findByEmail($email)===false){
            echo"Nenhum usuário foi encontrado";
            $user= new User();

            $userToken=$user->generatePassword($password);
            $user->name = $nome;
            $user->lastname = $ultimoNome;
            $user->email = $email; 
            $user->password = $finalPassword;
            $user->token = $userToken;
            $auth = true;
            $userDao->create($user, $auth);

        }
        else{
            $message->setMessage("Já existe um email cadastrado na base!", "error", "back");
        }
    }
    else{
        $message->setMessage("Por favor preencha todos os campos", "error", "back");
    }

}
?>